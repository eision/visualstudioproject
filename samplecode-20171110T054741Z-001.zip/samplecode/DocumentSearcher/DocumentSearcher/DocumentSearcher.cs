﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Doc;
using System.Net;
using System.IO;
using System.Xml;
using Vec;

namespace DocumentSearch
{
    public class DocumentSearcher
    {
        private List<Document> docs;

        public DocumentSearcher(List<Document> docs) {
            this.docs = docs;
        }

        //形態素解析
        public string[] Analyse(string str)
        {

            LinkedList<string> resultsurface = new LinkedList<string>();

            //解析する文字列はURLエンコードする
            String postString = String.Format("appid=dj00aiZpPW4zVzlxV2lWUXdXWCZzPWNvbnN1bWVyc2VjcmV0Jng9OTY-&sentence=" + str);

            //UTF8でバイト配列にエンコードする
            byte[] postData = Encoding.UTF8.GetBytes(postString);

            //Webリクエストを生成する
            WebRequest webReq = WebRequest.Create("http://jlp.yahooapis.jp/MAService/V1/parse");
            webReq.Method = "POST";
            webReq.ContentType = "application/x-www-form-urlencoded";
            webReq.ContentLength = postData.Length;

            //Postするデータを出力する
            using (Stream writer = webReq.GetRequestStream())
            {
                writer.Write(postData, 0, postData.Length);
            }

            //結果をうけとってDOMオブジェクトにする
            WebResponse webRes = webReq.GetResponse();

            XmlDocument resultXml = new XmlDocument();

            using (StreamReader reader = new StreamReader(webRes.GetResponseStream()))
            {
                resultXml.Load(reader);
            }

            //結果XML中の[word]タグのリストを取得する
            XmlNodeList wordList = resultXml.GetElementsByTagName("word");

            //[word]以下のノードに含まれる内容をresultsurfaceに記録
            foreach (XmlNode wordNode in wordList)
            {
                foreach (XmlNode resultNode in wordNode.ChildNodes)
                {
                    if (resultNode.Name == "surface")
                    {
                        resultsurface.AddLast(resultNode.InnerText);
                    }
                }
            }

            string[] result = new string[resultsurface.Count];
            int length = resultsurface.Count;
            for (int i = 0; i < length; i++)
            {
                string part = resultsurface.First.Value;
                result[i] = part;
                resultsurface.RemoveFirst();
            }
            return result;
        }

        //クエリ作成
        public double[] makequery(LinkedList<string> kinds, string[] textana)
        {
            LinkedList<double> textquery = new LinkedList<double>();
            double num;

            foreach (string e in kinds)
            {
                num = 0;
                for (int i = 0; i < textana.Length; i++)
                {
                    if (textana[i] == e)
                    {
                        num++;
                    }
                }
                textquery.AddLast(num);
                num = 0;
            }
            return textquery.ToArray();
        } 

        // Cosine計算
        public Dictionary<int, double> Cosine(string[] kensaku)
        {
            Dictionary<int, double> Cosresult = new Dictionary<int, double>(); ;
            int count = 0;
            string[][] textana = null;
            Vector[] textquery = null;
            Vector idfquery;
            Vector searchquery;
            double[] df = {0};
            double[] idf = {0};
            double searchnorm;
            double textnorm = 0;
            LinkedList<string> kinds = new LinkedList<string>();
            double naiseki;
            Dictionary<string, List<string>> a = new Dictionary<string, List<string>>();
            List<List<string>> b = new List<List<string>>();

            List<string> words = new List<string>();
            words.Add("word1");

            b.Add(words);


            foreach (Document e in this.docs)
            {
                textana[count] = Analyse(e.Body);
                count++;
            }

            // 種類の動的配列
            for (int i = 0; i < textana.Length; i++)
            {
                kinds.AddLast(textana[0][i]);
            }
            foreach (string[] str in textana)
            {      
                for (int j = 0; j < str.Length; j++)
                {
                    if (!(kinds.Contains(str[j])))
                    {
                        kinds.AddLast(str[j]);
                    }
                }
            }
            
            count = 0;
            //query作成
            foreach (string[] str in textana)
            {
                textquery[count] = new Vector(makequery(kinds, str));
                count++;
            }
            searchquery = new Vector(makequery(kinds, kensaku));

            //IDF
            for (int i = 0; i < textquery[0].Dimension; i++)
            {
                for (int j = 0; j < textquery.Length; j++) {
                    if (textquery[j].GetValue(i) > 0)
                    {
                        df[i]++;
                    }
                }
                idf[i] = Math.Log(100 / df[i]);
            }
            idfquery = new Vector(idf);

            //最終計算前query    
            for(int i=0;i<textquery.Length;i++){
                textquery[i] = textquery[i].Mult(idfquery);
            }
            searchquery = searchquery.Mult(idfquery);

            //Cosine計算(まだ計算できていない)
            searchnorm = searchquery.Norm();
            for (int i = 0; i < textquery.Length; i++)
            {
                naiseki = searchquery.InnerProduct(textquery[i]);
                textnorm = textquery[i].Norm();
                Cosresult.Add(i,(naiseki / (searchnorm * textnorm)));
            } 
            return Cosresult;
        }

        public List<Document> Search(string query) { 
            //string query を vector に直す
            string[] kensaku;
            Dictionary<int, double> searchValues;
            List<Document> searchResult = new List<Document>(); 
            kensaku = Analyse(query);
            //検索queryと this.bodyのCosine計算
            searchValues = Cosine(kensaku);
            //計算値のcosが大きいものから順に並べる
            var vs1 = searchValues.OrderBy((x) => x.Value);
            foreach (var v in vs1)
            {
                searchResult.Add(this.docs[v.Key]);
            }
            //並べたDocumentを返す
            return searchResult;
        }
    }
}
